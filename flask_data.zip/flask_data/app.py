from flask import Flask,render_template
import pyodbc,time
app = Flask(__name__)



#厂商价格变化文件
update_path='D:/project/AnyPromo_work/flask_data/file_path/update_qlp_'
#厂商新增商品
new_path='D:/project/AnyPromo_work/flask_data/file_path/new_qlp_'
#下架厂商商品文件
delete_path='D:/project/AnyPromo_work/flask_data/file_path/delete_qlp_'
# 厂商
Vendor = 'qlp'


#这里是需要读取邮件的地方
def readfile(path):              # 读取文件的函数
    content = [line.strip() for line in open(path, encoding='utf-8',errors='ignore').readlines()]
    return content

########设置起始主页
@app.route('/')
def index():
    datalist = []
    # 当前时间
    n_time = time.strftime("%d", time.localtime())
    # #设置时间范围 从月初到当天时间
    for data_time in range(int(n_time),0,-1):
        #每天的时间段
        monthly_daytime = time.strftime("%Y-%m-", time.localtime()).strip() + ('0' + str(data_time))[-2:]
        #厂商文件日期
        Vendor_time = time.strftime("%Y_%m_", time.localtime()).strip() + ('0' + str(data_time))[-2:]

        '''读取查看是否有新增商品'''
        try:
            new_list = readfile(new_path + Vendor_time + '.csv')
            new_changed = str(len(new_list) - 1)
        except:
            new_changed = '0'

        '''读取查看是否有更新商品'''
        try:
            updata_list = readfile(update_path + Vendor_time + '.csv')
            updata_changed = str((len(updata_list) - 1) // 2)  # -1 是去除标题
        except:
            updata_changed = '0'

        '''读取查看是否有下架商品'''
        try:
            delete_list = readfile(delete_path + Vendor_time + '.csv')
            delete_changed = str(len(delete_list) - 1)
        except:
            delete_changed = '0'

        #变化数量
        Variation = str(int(new_changed)+int(updata_changed)+int(delete_changed))

        type_list = [monthly_daytime,Variation,new_changed,updata_changed,delete_changed]

        datalist.append(type_list)


    return render_template('template_index.html', prices=datalist)



#设置主页
@app.route('/index')
def home():
    return index()

#新增商品信息
@app.route('/new')
def new():
    new_datalist = []
    n_time = time.strftime("%d", time.localtime())
    # #设置时间范围 从月初到当天时间
    for data_time in range(int(n_time),0,-1):
        #每天的时间段
        monthly_daytime = time.strftime("%Y-%m-", time.localtime()).strip() + ('0' + str(data_time))[-2:]

        # 删除文件信息厂商文件日期
        new_time = time.strftime("%Y_%m_", time.localtime()).strip() + ('0' + str(data_time))[-2:]

        try:
            list_urls = readfile(new_path + new_time + '.csv')[1:]
        except:
            list_urls = ''

        for new_item in list_urls:
            new_item = [monthly_daytime]+new_item.split(',')
            new_datalist.append(new_item)
    return render_template('template_new.html',new_item=new_datalist)

#更新信息
@app.route('/update')
def update():
    update_datalist = []
    n_time = time.strftime("%d", time.localtime())
    # #设置时间范围 从月初到当天时间
    for data_time in range(int(n_time),0,-1):
        # 每天的时间段
        monthly_daytime = time.strftime("%Y-%m-", time.localtime()).strip() + ('0' + str(data_time))[-2:]
        # 删除文件信息厂商文件日期
        update_time = time.strftime("%Y_%m_", time.localtime()).strip() + ('0' + str(data_time))[-2:]

        try:
            list_urls = readfile(update_path + update_time + '.csv')[1:]
        except:
            list_urls = ''

        for update_item in list_urls:
            update_item = [monthly_daytime]+update_item.split(',')

            update_datalist.append(update_item)
    return render_template('template_update.html',update_item=update_datalist)

#下线商品信息
@app.route('/delete')
def delete():
    delete_datalist = []
    n_time = time.strftime("%d", time.localtime())
    # #设置时间范围 从月初到当天时间
    for data_time in range(int(n_time),0,-1):
        # 每天的时间段
        monthly_daytime = time.strftime("%Y-%m-", time.localtime()).strip() + ('0' + str(data_time))[-2:]
        #删除文件信息厂商文件日期
        delete_time = time.strftime("%Y_%m_", time.localtime()).strip() + ('0' + str(data_time))[-2:]

        try:
            list_urls = readfile(delete_path + delete_time + '.csv')[1:]
        except:
            list_urls = ''

        for delete_item in list_urls:
            try:
                delete_url = delete_item.split(',')[0]
            except:
                delete_url = ''
            try:
                delete_VendorItemNo = delete_item.split(',')[1]
            except:
                delete_VendorItemNo = ''
            item_list = [monthly_daytime,delete_url,delete_VendorItemNo]

            delete_datalist.append(item_list)

    return render_template('template_delete.html',delect_item=delete_datalist)



if __name__ == '__main__':
    # new()
    app.run()
    # index()
    # update()
